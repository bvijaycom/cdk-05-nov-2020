def main(event, context):
    print("Hi! i am python function app")